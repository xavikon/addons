//sellnpc [item]
//sellnpc Acheron shield
Talk to npc first, then will sell all of the item in your inventory (works with Green Thumb Moogle!)
