# SkillChains
### Active Battle Skillchain Display.

Displays a text object containing skillchain elements resonating on current target, timer for skillchain window,
along with a list of weapon skills that can skillchain based on the weapon you have currently equipped. 

No commands at this time, text box can be repositioned by clicking down and dragging it to a new location.

Other settings related to text object can be found within the settings.xml, generated on addon load.
